 </section>
<section class="footeroption">
		<h2><?php echo "Developed By MD. Rafiqul Islam"; ?></h2>
	</section>
</div>
</body>
</html>