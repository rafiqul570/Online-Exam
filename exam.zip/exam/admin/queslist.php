<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	include_once ($filepath.'/../classes/Exam.php');
	$exm = new Exam();
?>
<?php 
if (isset($_GET['dis'])) {
		$dis = (int)$_GET['dis'];
		$disQuestion = $exm->disableQuestion($dis);
	}

	if (isset($_GET['ena'])) {
		$ena = (int)$_GET['ena'];
		$enQuestion = $exm->enableQuestion($ena);
	}

if (isset($_GET['delque'])) {
		$quesno = (int)$_GET['delque'];
		$delQue = $exm->delQuestion($quesno);
	}
 ?>

<div class="main">
	<h1>Admin Panel - Question List</h1>

	<?php
		if (isset($disQuestion)) {
			echo $disQuestion;
		}

		if (isset($enQuestion)) {
			echo $enQuestion;
		} 
		if (isset($delQue)) {
			echo $delQue;
		}
	 ?>

<div class="quelist">
	<table class="tblone">
		
		<tr>
			<th width="10%">No</th>
			<th width="70%">Questions</th>
			<th width="20%">Action</th>
		</tr>

<?php 

$getData = $exm->getAllQues();
if ($getData) {
	$i = 0;
	while ($result = $getData->fetch_assoc()) {
		$i++;

 ?>
		<tr>
		   <td>
				<?php 
				if ($result['status'] == '0') {
					echo "<span class='error'>".$i."</span>"; 
				}else{
					echo $i;
				}
			
				?>
				
			</td>
			
			<td><?php echo $result['ques']; ?></td>
			<td>
				<?php
					if ($result['status'] == '1') { ?>
						<a href="?dis=<?php echo $result['id'];?>">Disable</a>
					<?php } else{ ?>
						<a href="?ena=<?php echo $result['id'];?>">Enable</a>
					<?php }?>
				|| <a onclick="return confirm('Are You Sure to Remove')" href="?delque=<?php echo $result['quesNo'];?>">Remove</a>
			</td>

		</tr>

	<?php  }} ?>

	</table>

</div>

	
</div>
<?php include 'inc/footer.php'; ?>